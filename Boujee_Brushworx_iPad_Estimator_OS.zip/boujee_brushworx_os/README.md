# Boujee Brush-worx Estimator OS

This is an iPad-friendly web app prototype for Boujee Brush-worx.

## What it includes
- Mobile/iPad layout
- Dashboard
- New estimate screen
- Dulux material database
- Automatic 4L / 10L / 15L tin optimisation
- 6% annual price increase input
- Labour at $85/hr by default
- 30% markup setting
- Job costing: estimated vs actual
- Client estimate text generator
- Material order list generator
- Local data saving in the browser

## How to use on iPad
The easiest way is to upload this folder to a simple web host such as GitHub Pages, Netlify, Vercel, or your website hosting.

Once hosted:
1. Open the app link in Safari on your iPad.
2. Tap Share.
3. Tap Add to Home Screen.
4. Open it like a normal app.

## Local testing on a computer
Open `index.html` in a browser, or serve the folder with a simple local server.

## Important
This is a working prototype. Product prices and production rates are starter defaults and should be checked against your real supplier pricing and actual job data.
