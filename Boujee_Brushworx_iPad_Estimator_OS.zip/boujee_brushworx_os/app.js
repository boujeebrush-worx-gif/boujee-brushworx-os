const defaultMaterials = [
  {name:'Dulux Wash & Wear', coverage:16, sizes:{4:78,10:168,15:235}, notes:'Interior walls, premium washable finish'},
  {name:'Dulux Wash & Wear Plus', coverage:16, sizes:{4:88,10:190,15:270}, notes:'Higher durability interior walls'},
  {name:'Dulux Enviro2', coverage:16, sizes:{4:72,10:155,15:225}, notes:'Low odour interior walls/ceilings'},
  {name:'Dulux Weathershield', coverage:16, sizes:{4:95,10:220,15:315}, notes:'Exterior surfaces'},
  {name:'Dulux Aquanamel', coverage:16, sizes:{4:105,10:245}, notes:'Trims, doors, windows'},
  {name:'Dulux 1Step Prep', coverage:12, sizes:{4:82,10:180,15:255}, notes:'Prepcoat / primer / sealer'},
  {name:'Dulux Precision Prepcoat', coverage:10, sizes:{4:98,10:230}, notes:'Specialty prep / problem surfaces'}
];
const production = {ceil:0.11, wall:0.14, trim:0.08, door:0.65, window:0.55};
let state = JSON.parse(localStorage.getItem('bbwOS')||'{}');
state.settings = state.settings || {labourRate:85, markup:30, gst:10, businessName:'Boujee Brush-worx'};
state.materials = state.materials || defaultMaterials;
let latest = state.latest || null;
const $ = id => document.getElementById(id);
const money = n => (Number(n)||0).toLocaleString('en-AU',{style:'currency',currency:'AUD',maximumFractionDigits:0});
function save(){ state.latest = latest; localStorage.setItem('bbwOS', JSON.stringify(state)); }
function populateProducts(){ ['ceilProduct','wallProduct','trimProduct','doorProduct','windowProduct'].forEach(id=>{ const sel=$(id); sel.innerHTML=''; state.materials.forEach((m,i)=>{ const o=document.createElement('option'); o.value=i; o.textContent=m.name; sel.appendChild(o); }); }); $('ceilProduct').value=2; $('wallProduct').value=0; $('trimProduct').value=4; $('doorProduct').value=4; $('windowProduct').value=4; }
function tinOptimise(litres, mat, increasePct){ const sizes=Object.keys(mat.sizes).map(Number).sort((a,b)=>b-a); let best=null; const inc=1+(Number(increasePct)||0)/100; for(let a=0;a<=Math.ceil(litres/4)+6;a++) for(let b=0;b<=Math.ceil(litres/10)+6;b++) for(let c=0;c<=Math.ceil(litres/15)+6;c++){ const combo={4:a,10:b,15:c}; let totalL=0,cost=0; for(const s of sizes){ totalL+=combo[s]*s; cost+=combo[s]*(mat.sizes[s]||0)*inc; } if(totalL>=litres && (!best || cost<best.cost || (cost===best.cost && totalL<best.totalL))) best={combo,totalL,cost,waste:totalL-litres}; } return best; }
function line(surface, amount, productIdx, coats, rateKey, wastePct, increasePct, prep){ const mat=state.materials[productIdx]; let paintArea = rateKey==='trim' ? amount*0.18 : rateKey==='door' ? amount*4 : rateKey==='window' ? amount*2.5 : amount; let litres = paintArea*coats/mat.coverage; litres *= 1+(wastePct/100); const tins=tinOptimise(litres, mat, increasePct); const hours = amount * production[rateKey] * coats * prep; return {surface, amount, product:mat.name, coats, litres, tins, hours}; }
function calculate(){ const prep=Number($('prepLevel').value); const waste=Number($('waste').value)||0; const increase=Number($('increase').value)||0; const items=[
 line('Ceilings', Number($('ceilArea').value)||0, Number($('ceilProduct').value), Number($('ceilCoats').value)||0, 'ceil', waste, increase, prep),
 line('Walls', Number($('wallArea').value)||0, Number($('wallProduct').value), Number($('wallCoats').value)||0, 'wall', waste, increase, prep),
 line('Trim', Number($('trimLength').value)||0, Number($('trimProduct').value), Number($('trimCoats').value)||0, 'trim', waste, increase, prep),
 line('Doors', Number($('doors').value)||0, Number($('doorProduct').value), Number($('doorCoats').value)||0, 'door', waste, increase, prep),
 line('Windows', Number($('windows').value)||0, Number($('windowProduct').value), Number($('windowCoats').value)||0, 'window', waste, increase, prep)
 ].filter(x=>x.amount>0 && x.coats>0);
 const furnitureHours=Number($('furnitureHours').value)||0, sundries=Number($('sundries').value)||0;
 const materialCost=items.reduce((s,i)=>s+i.tins.cost,0)+sundries;
 const labourHours=items.reduce((s,i)=>s+i.hours,0)+furnitureHours;
 const labourCost=labourHours*state.settings.labourRate;
 const subtotal=materialCost+labourCost;
 const markupAmount=subtotal*(state.settings.markup/100);
 const total=subtotal+markupAmount;
 latest={client:$('clientName').value, address:$('jobAddress').value, name:$('estimateName').value||'Painting estimate', items, materialCost, labourHours, labourCost, sundries, markupAmount, total, date:new Date().toLocaleDateString('en-AU')};
 save(); renderResults(); renderDash(); }
function comboText(t){ return Object.entries(t.combo).filter(([s,q])=>q>0).map(([s,q])=>`${q} × ${s}L`).join(', ') || 'No tins'; }
function renderResults(){ if(!latest){$('estimateResult').innerHTML='';return;} $('estimateResult').innerHTML = `<div class="grid cards"><article class="card"><span>Selling Price</span><strong>${money(latest.total)}</strong></article><article class="card"><span>Labour</span><strong>${latest.labourHours.toFixed(1)}h</strong></article><article class="card"><span>Materials</span><strong>${money(latest.materialCost)}</strong></article><article class="card"><span>Markup</span><strong>${money(latest.markupAmount)}</strong></article></div>` + latest.items.map(i=>`<p><b>${i.surface}</b> — ${i.product}: ${i.litres.toFixed(1)}L required. Buy <span class="good">${comboText(i.tins)}</span> (${i.tins.totalL}L, waste ${i.tins.waste.toFixed(1)}L). Cost ${money(i.tins.cost)}. Labour ${i.hours.toFixed(1)}h.</p>`).join(''); }
function renderDash(){ $('dashTotal').textContent=money(latest?.total||0); $('dashHours').textContent=(latest?.labourHours||0).toFixed(1)+'h'; $('dashMaterials').textContent=money(latest?.materialCost||0); $('dashMarkup').textContent=money(latest?.markupAmount||0); $('summaryText').innerHTML = latest ? `<b>${latest.name}</b><br>${latest.client||'No client entered'} — ${latest.address||'No address entered'}<br>Total: <b>${money(latest.total)}</b>` : 'Create an estimate to see your totals here.'; }
function renderMaterials(){ $('materialList').innerHTML = state.materials.map(m=>`<div class="material-card"><div><b>${m.name}</b><br><span class="pill">Coverage ${m.coverage} m²/L</span>${Object.entries(m.sizes).map(([s,p])=>`<span class="pill">${s}L ${money(p)}</span>`).join('')}<p>${m.notes}</p></div></div>`).join(''); }
function jobCost(){ if(!latest){$('costResult').innerHTML='Create an estimate first.'; return;} const ah=Number($('actualHours').value)||0, am=Number($('actualMaterials').value)||0; const actualCost=ah*state.settings.labourRate+am; const estimatedCost=latest.labourCost+latest.materialCost; const diff=estimatedCost-actualCost; $('costResult').innerHTML=`<p>Estimated internal cost: <b>${money(estimatedCost)}</b><br>Actual internal cost: <b>${money(actualCost)}</b><br>Difference: <b class="${diff>=0?'good':'bad'}">${money(diff)}</b></p>`; }
function proposal(){ if(!latest){$('docOutput').value='Create an estimate first.'; return;} $('docOutput').value=`${state.settings.businessName}\nClient Estimate\n\nDate: ${latest.date}\nClient: ${latest.client}\nAddress: ${latest.address}\nProject: ${latest.name}\n\nScope Summary:\n${latest.items.map(i=>`- ${i.surface}: ${i.amount} using ${i.product}, ${i.coats} coats`).join('\n')}\n\nEstimated labour: ${latest.labourHours.toFixed(1)} hours\nEstimated materials: ${money(latest.materialCost)}\nTotal estimated price: ${money(latest.total)}\n\nPayment terms: 20% deposit to secure dates, progress payment where applicable, and balance due on completion/practical completion.`; }
function orderList(){ if(!latest){$('docOutput').value='Create an estimate first.'; return;} $('docOutput').value=`Material Order List\n\n${latest.items.map(i=>`${i.product} for ${i.surface}: ${comboText(i.tins)} (${i.tins.totalL}L total)`).join('\n')}\nSundries allowance: ${money(latest.sundries)}`; }
function loadSettings(){ $('labourRate').value=state.settings.labourRate; $('markup').value=state.settings.markup; $('gst').value=state.settings.gst; $('businessName').value=state.settings.businessName; }
document.querySelectorAll('.tab').forEach(btn=>btn.onclick=()=>{document.querySelectorAll('.tab,.screen').forEach(x=>x.classList.remove('active')); btn.classList.add('active'); $(btn.dataset.screen).classList.add('active');});
$('calcBtn').onclick=calculate; $('costBtn').onclick=jobCost; $('proposalBtn').onclick=proposal; $('orderBtn').onclick=orderList; $('saveSettings').onclick=()=>{state.settings={labourRate:Number($('labourRate').value)||85,markup:Number($('markup').value)||30,gst:Number($('gst').value)||10,businessName:$('businessName').value||'Boujee Brush-worx'}; save(); renderDash(); alert('Settings saved');};
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='boujee-brushworx-os-data.json'; a.click();};
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js'); populateProducts(); loadSettings(); renderMaterials(); renderResults(); renderDash();
